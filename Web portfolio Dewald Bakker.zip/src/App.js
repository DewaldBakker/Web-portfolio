import { useState, useEffect } from 'react';
import './App.css';
import Home from './Components/Home/Home';
import Info from './Components/Info/Info';
import Header from './Components/Header/Header';
import About from './Components/About/About';
function App() {
  //home page
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % Info.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  //about page
  const [who,setwho]=useState(null)
  const [id,setid]=useState(0)
  function Prev(){
    setid((prev)=>(prev-1+Info.length)%Info.length)};

  function Next(){
    setid((prev)=>(prev+1)%Info.length)};

  useEffect(()=>{
    setwho(Info[id])
  },[id])
  return (
    <div>
      <Header/>
      <Home img={Info[index].img} name={Info[index].name} />
      <button onClick={Next}>Next</button>
      <button onClick={Prev}>Prev</button>
      {who&&(
        <About Name={Info[id].name.toUpperCase()}Info={Info[id].Info} Design={Info[id].Design} Development={Info[id].Development} Maintenance={Info[id].Maintenance}/>
      )}

    </div>
  );
}

export default App;