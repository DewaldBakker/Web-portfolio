import React from 'react';

function Home({ img, name }) {
  return (
    <div>
      <div id='home' style={{display:'grid', gridTemplateColumns:'repeat(2,1fr)', color:'white', height:'450px'}}>

        <div className='left' style={{backgroundColor:'#209B6E',display:'flex', justifyContent:'center', alignItems:'center'}}>
          <h1>
            Hi, we are<br/>
            Group DKH<br/>
            Front-end Developers/UI Designers
          </h1>
        </div>

        <div className='right' style={{backgroundColor:'black', height:'450px'}}>
          <img src={img} alt={name} style={{width:'100%', height:'450px'}}/>
        </div>

      </div>

      <div className='HomeF' style={{backgroundColor:'black', color:'white', padding:'40px'}}>
        <h1>What we do</h1>
        <p>
          We are a group of 3 people that design websites front-end, the UI that people see.<br/>
          We work hard by dividing the work up evenly between the 3 of us so we can deliver an amazing product for our clients
        </p>
      </div>
    </div>
  );
}

export default Home;