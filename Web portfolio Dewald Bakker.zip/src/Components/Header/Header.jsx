import React from 'react'
import './Header.css'
function Header() {

  const scrollToSection = (id) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };
  return (
    <div
      className='Header'
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(2,1fr)',
        backgroundColor: 'black',
        position: 'sticky',
        top: 0
      }}
    >
      <div className='logo'>
        <img />
      </div>

      <div>
            <div  className='options'>
              <a onClick={()=>scrollToSection('home')}>HOME</a>
              <a onClick={()=>scrollToSection('about')}>ABOUT</a>
              <a onClick={()=>scrollToSection('skills')}>SKILLS</a>
              <a onClick={()=>scrollToSection('port')}>PORTFOLIO</a>
              <a onClick={()=>scrollToSection('contact')}>CONTACT</a>
            </div>
      </div>
    </div>
  );
}

export default Header