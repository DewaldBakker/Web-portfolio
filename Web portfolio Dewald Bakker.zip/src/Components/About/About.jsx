import React from 'react';

function About({ Name,Info, Design, Maintenance, Development }) {

  return (
    <div
    id='about'
      style={{
        backgroundColor: '#2e8b57',
        color: 'white',
        textAlign: 'center',
        padding: '60px 20px'
      }}
    >
      <div
        style={{
          border: '3px solid white',
          display: 'inline-block',
          padding: '15px 40px',
          fontWeight: 'bold',
          letterSpacing: '4px',
          marginBottom: '30px'
        }}
      >ABOUT {Name}</div>


      <p style={{ maxWidth: '600px', margin: '0 auto 30px' }}>
        {Info}
      </p>

      <div style={{ marginBottom: '50px', letterSpacing: '2px' }}>
        | EXPLORE |
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '40px',
          maxWidth: '800px',
          margin: '0 auto'
        }}
      >
        <div>
          <h3 style={{ letterSpacing: '3px' }}>DESIGN</h3>
          <p>{Design}</p>
        </div>

        <div>
          <h3 style={{ letterSpacing: '3px' }}>DEVELOPMENT</h3>
          <p>{Development}</p>
        </div>

        <div
          style={{
            gridColumn: '1 / span 2',
            maxWidth: '400px',
            margin: '0 auto'
          }}
        >
          <h3 style={{ letterSpacing: '3px' }}>MAINTENANCE</h3>
          <p>{Maintenance}</p>
        </div>
      </div>
    </div>
  );
}

export default About;