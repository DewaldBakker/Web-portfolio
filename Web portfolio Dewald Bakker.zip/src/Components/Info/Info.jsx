let info=[
    {name:'Dewald',
     img:'Dewald.jpeg',
    Info:`My name is Dewald Bakker and I was a student at Belgium Campus.
    At BC I learned how to build clean and function websites using ReactJS`,
    Design:'I can design the site based on your needs and suggestions. I can also design the site from scratch and consult you during the job.',
    Development:'I can develop your websites using ReactJS',
    Maintenance:'I can do maintenace for the websites from my home or in the office'},
    {name:'Kalyan',
     img:'Kalyan.jpg',
    Info:`Info added soon`,
    Design:'Info added soon',
    Development:'Info added soon',
    Maintenance:'Info added soon'},
    {name:'Hanno',
     img:'Hanno.jpg',
    Info:`Info added soon`,
    Design:'Info added soon',
    Development:'Info added soon',
    Maintenance:'Info added soon'}
]
export default info