import React from "react";
import ContactLink from "./ContactLink";

function Contact() {
  const contactLinks = [
    {
      icon: "✉",
      label: "Email",
      value: "601829@student.belgiumcampus.ac.za",
      href: "mailto:601829@student.belgiumcampus.ac.za",
    },{
      icon: "☏",
      label: "Phone",
      value: "+27 84 223 2813",
      href: "tel:+27 84 223 2813",
    },
    {
      icon: "in",
      label: "LinkedIn",
      value: "linkedin.com/in/dewald-bakker-b498403b2",
      href: "https://www.linkedin.com/in/dewald-bakker-b498403b2/",
      target: "_blank",
      rel: "noopener noreferrer",
    },
    {
      icon: "GH",
      label: "GitHub",
      value: "github.com/DewaldBakker",
      href: "https://github.com/DewaldBakker",
      target: "_blank",
      rel: "noopener noreferrer",
    },
  ];

  return (
    <section id="contact" className="contact-section">
      <h2 className="contact-title">
        Get in touch
      </h2>

      <h2 className="contact-tagline">
        Let's build<br /><em>something</em><br />together.
      </h2>

      <p className="contact-desc">
        Open to junior roles, freelance work, or collaborations. Whether it's
        a project idea or just a coffee chat about code — I'm in.
      </p>

      <div className="contact-links">
        {contactLinks.map((link) => (
          <ContactLink key={link.label} {...link} />
        ))}
      </div>
    </section>
  );
}

export default Contact;