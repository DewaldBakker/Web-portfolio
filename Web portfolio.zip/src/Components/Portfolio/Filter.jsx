import React from 'react';

function Filter({ currentFilter, setFilter }) {
  return (
    <div className="portfolio-filter-bar">
      <span className={currentFilter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>All</span>

      <span className={currentFilter === 'reactjs' ? 'active' : ''} onClick={() => setFilter('Reactjs')}>ReactJS</span>

      <span className={currentFilter === 'sql' ? 'active' : ''} onClick={() => setFilter('SQL')}>SQL</span>

      <span className={currentFilter === 'csharp' ? 'active' : ''} onClick={() => setFilter('C#')}>C#</span>
    </div>
  );
}

export default Filter;